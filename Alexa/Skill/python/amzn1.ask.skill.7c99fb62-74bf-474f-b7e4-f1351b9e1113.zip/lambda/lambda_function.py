# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import socket
import logging
import ask_sdk_core.utils as ask_utils

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

TCP_IP = 'echao.asuscomm.com'
TCP_PORT = 6000
BUFFER_SIZE = 1024
Tin = b'hlocalTemp,4'
Tout = b'temp,2'



class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hola Bró!. Puedes pedirme cosas como; pregunta a mai home la temperatura. abre mai home y mantén temperatura ideal. abre  mai Home y mantén 21 grados. abre  mai Home y sube 1 grado. abre  mai Home y apaga la calefacción. pregunta mai home estado de calefección"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class HelloWorldIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hello World!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )
    
class ConnectToServer():
    def send(messa,aType="b"):
        
        messa = bytes(messa, 'utf-8')
        
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((TCP_IP, TCP_PORT))
        s.send(messa)
        repli = s.recv(BUFFER_SIZE)
        s.close()
        
        if aType == "b":
            return repli
            
        if aType == "utf-8":
            return repli.decode('utf-8')
            
        if aType == "int":
            return int(repli.decode('utf-8'))

class CalefaccionStatusIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CalefaccionStatusIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        work = ConnectToServer.send("hworking,1","b")
        up = ConnectToServer.send("hstatus,1","b")
        tempActual = ConnectToServer.send("hlocalTemp,1","b")
        tempToArrive = ConnectToServer.send("htrigger,1","b")
        
        if up == b'0':
            speak_output = "La calefacción está apagada!"
        else:
            if work == b'0':
                speak_output = "Encendida y se ha alcanzado la temperatura programada de: " + tempToArrive.decode("utf-8") +". Ahora hay en casa: " + tempActual.decode("utf-8") + "grados"
            else:
                speak_output = "Encendida y tratando de alcanzar la temperatura programada de: " + tempToArrive.decode("utf-8") +". Ahora hay en casa: " + tempActual.decode("utf-8") + "grados"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class CalefacionOffIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CalefacionOffIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        ConnectToServer.send("hOff,5")
        speak_output = "Parando la calefacción"
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class CalefaccionRaiseIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CalefaccionRaiseIntent")(handler_input)
    
    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        slots = handler_input.request_envelope.request.intent.slots
        grado = slots['grado']
        messa = "hRaise,"+str(grado.value)
        messa = bytes(messa, 'utf-8')
        
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((TCP_IP, TCP_PORT))
        s.send(messa)
        #inside = s.recv(BUFFER_SIZE)
        s.close()
        
        speak_output = "Subiendo la temperatura de casa "+grado.value+" grado"
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class CalefaccionIdealIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CalefaccionIdealIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> bool
        ConnectToServer.send("hStay,21.5")
        speak_output = "Mantendré la temperatura de casa a 21.5 grados"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class CalefaccionStayIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CalefaccionStayIntent")(handler_input)

    def handle(self, handler_input):
        
        slots = handler_input.request_envelope.request.intent.slots
        grado = slots['grado']
        decimal = slots['decimal']
        
        if decimal.value == None:
            messa = "hStay,"+str(grado.value)
            speak_output = "Mantendré la temperatura de casa a "+grado.value+"grados"
        else:
            messa = "hStay,"+str(grado.value)+"."+str(decimal.value)
            speak_output = "Mantendré la temperatura de casa a "+grado.value+"punto"+decimal.value+"grados"
        
        ConnectToServer.send(messa)
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class CasaTemperaturaIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("CasaTemperaturaIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        inside = ConnectToServer.send("hlocalTemp,4","utf-8")
        out = ConnectToServer.send("temp,2","utf-8")
        #out = ConnectToServer.send("temp,2","int")
        
        #millivolts = (out/1024.0) * 3300;
        #celsius = millivolts/10;
        #celsius = celsius -1
        #out = "{0:.1f}".format(celsius)
        
        if  (float(out) < 8):
            speak_output = "En casa "+inside+" grados. y suajili pilili en la calle hace fresculini. "+str(out) + "grados"
        else:
            speak_output = "En casa "+inside+" grados. y fuera, de "+str(out)
        

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Bró!, Creo que no te he entendido o hay un fallo de conexión con el servidor o vay usted a saber!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(CalefacionOffIntentHandler())
sb.add_request_handler(CalefaccionRaiseIntentHandler())
sb.add_request_handler(CalefaccionIdealIntentHandler())
sb.add_request_handler(CalefaccionStayIntentHandler())
sb.add_request_handler(CalefaccionStatusIntentHandler())
sb.add_request_handler(CasaTemperaturaIntentHandler())

sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()